"""
Novel's IPX
"""