"""
the Post Office Protocol v3 (POP3) protocol
"""

