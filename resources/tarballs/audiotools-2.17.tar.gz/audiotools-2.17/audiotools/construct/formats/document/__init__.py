"""
document file formats (doc, wri, odf, xls, ...)
"""